<style>
 @import url(https://fonts.googleapis.com/css?family=Roboto:100" rel="stylesheet);
    h3 {
    font-size: 2em;
    color: chocolate;
      font-family: 'Roboto', sans-serif;
      font-weight: 100;
}
input {
    font-size: 1em;
  }
</style>



<h3>Upload your images: <?php echo $name; ?></h3>



<?php echo form_open_multipart('upload/do_upload');?>

<input type="file" name="userfile" size="20" />

<br /><br />

<input type="submit" value="upload" />

</form>